-- phpMyAdmin SQL Dump
-- version 3.1.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 20, 2022 at 12:00 PM
-- Server version: 5.1.32
-- PHP Version: 5.2.9-1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `finance_alert`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill_info`
--

CREATE TABLE IF NOT EXISTS `bill_info` (
  `bill_id` int(100) NOT NULL AUTO_INCREMENT,
  `bill_no` varchar(250) NOT NULL,
  `bill_date` date NOT NULL,
  `bill_category` varchar(50) NOT NULL,
  `bill_amount` varchar(50) NOT NULL,
  `due_date` date NOT NULL,
  `reminder_date` date NOT NULL,
  `family_member` varchar(250) NOT NULL,
  `bill_status` varchar(50) NOT NULL,
  `bill_note` text NOT NULL,
  PRIMARY KEY (`bill_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `bill_info`
--

INSERT INTO `bill_info` (`bill_id`, `bill_no`, `bill_date`, `bill_category`, `bill_amount`, `due_date`, `reminder_date`, `family_member`, `bill_status`, `bill_note`) VALUES
(30, '435', '2022-11-17', 'EB', '453', '2022-11-26', '2022-11-16', 'egsdfg', 'dgdg', 'dgdfhdfhdhhrt'),
(29, '', '0000-00-00', '', '', '0000-00-00', '0000-00-00', '', '', ''),
(28, '', '0000-00-00', '', '', '0000-00-00', '0000-00-00', '', '', ''),
(27, '', '0000-00-00', '', '', '0000-00-00', '0000-00-00', '', '', ''),
(26, '', '0000-00-00', '', '', '0000-00-00', '0000-00-00', '', '', ''),
(25, '', '0000-00-00', '', '', '0000-00-00', '0000-00-00', '', '', ''),
(24, '', '0000-00-00', '', '', '0000-00-00', '0000-00-00', '', '', ''),
(23, '', '0000-00-00', 'jewel_loan', '', '0000-00-00', '0000-00-00', '', '', ''),
(22, 'et', '2022-11-01', '', '', '2022-11-10', '2022-11-05', '', '', ''),
(21, '3r', '2022-11-01', 'life_insurance', '', '2022-11-30', '2022-11-17', '', '', ''),
(18, 'AE1', '2022-11-08', 'eb', '', '2022-11-25', '2022-11-15', '', '', ''),
(19, '1', '2022-11-11', 'gas', '', '2022-11-25', '2022-11-15', '', '', ''),
(20, '', '2022-11-26', 'car_loan', '', '2022-11-19', '2022-11-30', '', '', ''),
(33, '458', '2022-11-01', 'house_rent', '', '2022-11-30', '2022-11-20', '9042222230', '', 'fsgfd'),
(32, '457', '2022-11-01', 'car_insurance', '', '2022-11-30', '2022-11-20', '', '', ''),
(31, '456', '2022-11-01', '', '', '2022-11-30', '2022-11-20', '', '', ''),
(34, '498', '2022-11-16', 'house_rent', '5656', '2022-11-18', '2022-11-25', '9042222231', '', 'uutyjfhjghn'),
(35, '1111111111111111', '2022-11-16', 'GAS', '76467546546', '2022-11-26', '2022-11-30', '9941078544', 'Paid', ''),
(36, '4288', '2022-11-17', 'HOUSE_RENT', '35354', '2022-11-26', '2022-11-22', '9042222231', 'Not Paid', 'erterywey'),
(37, '', '2022-11-16', '', '', '0000-00-00', '0000-00-00', '', '', ''),
(38, '', '0000-00-00', '', '', '0000-00-00', '0000-00-00', '', '', ''),
(39, '800000', '2022-11-26', 'LIFE_INSURANCE', '45345', '2022-11-23', '2022-11-20', 'sushmajeyamary2004@gmail.com', 'Not Paid', 'ttrthrth'),
(40, '800000', '2022-11-26', 'LIFE_INSURANCE', '45345', '2022-11-23', '2022-11-20', 'sushmajeyamary2004@gmail.com', 'Not Paid', 'ttrthrth'),
(41, '5446', '2022-11-20', 'HOUSE_RENT', '43365', '2022-11-26', '2022-11-20', 'sushmajeyamary2004@gmail.com', 'Not Paid', 'thfhfdgfhjkllkj ghggf fgf vggjghghg'),
(42, '5678', '2022-11-20', 'CAR_INSURANCE', '467364', '2022-11-30', '2022-11-25', 'sushmajeyamary2004@gmail.com', 'Not Paid', '');
