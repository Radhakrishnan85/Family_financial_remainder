<?php 
//include("include/constants.php");
include("include/dbconnect.php");

$bill_id=$_POST['bill_id'];
$bill_no=$_POST['bill_no'];
$bill_date=$_POST['bill_date'];
$bill_category=$_POST['bill_category'];
$bill_amount=$_POST['bill_amount'];
$due_date=$_POST['due_date'];
$reminder_date=$_POST['reminder_date'];
$family_member=$_POST['family_member'];
$bill_status=$_POST['bill_status'];
$bill_note=$_POST['bill_note'];


$InsQuery="INSERT INTO `bill_info` (
`bill_id` ,`bill_no` ,`bill_date` ,`bill_category` ,`bill_amount`,`due_date` ,`reminder_date` ,`family_member`,`bill_status`,`bill_note`
)
VALUES (
'$bill_id', '$bill_no', '$bill_date', '$bill_category', '$bill_amount', '$due_date', '$reminder_date', '$family_member', '$bill_status', '$bill_note'
)";
$ExQuery=mysql_query($InsQuery) or die(mysql_error());

echo mysql_error();


header("location:add_bill.php");

?>