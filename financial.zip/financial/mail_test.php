
<?php



include("include/dbconnect.php");

//$message='<p align="center" class="style2"><u>Daily report format  of the Executive Director&nbsp; People&rsquo;s Watch</u></p>';


 // $to = "sushmajeyamary2004@gmail.com";
// $email_regular = "amalavincyj@gmail.org";
// $subject = "Daily Report";
//$headers  = "Content-Type: text/html; charset=iso-8859-1\r\n";
//$headers .= "From:".$email_regular."<".$email_regular.">\r\n";

//mail($to,$subject,$message,$headers);



?>
<?php
//define the receiver of the email
$to = 'sushmajeyamary2004@gmail.com';
//define the subject of the email
$subject = 'Test email';
//define the message to be sent. Each line should be separated with \n
$message = "Hello World!\n\nThis is my first mail.";
//define the headers we want passed. Note that they are separated with \r\n
$headers = "From: amalavincyj@gmail.com\r\nReply-To: sushmajeyamary2004@gmail.com";
//send the email
$mail_sent = @mail( $to, $subject, $message, $headers );
//if the message is sent successfully print "Mail sent". Otherwise print "Mail failed" 
echo $mail_sent ? "Mail sent" : "Mail failed";
?>