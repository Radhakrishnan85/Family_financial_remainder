<?php 

include("include/dbconnect.php");


$bill_id=$_REQUEST['bill_id'];



$bill_id=$_POST['bill_id'];
$bill_no=$_POST['bill_no'];
$bill_date=$_POST['bill_date'];
$bill_category=$_POST['bill_category'];
$bill_amount=$_POST['bill_amount'];
$due_date=$_POST['due_date'];
$reminder_date=$_POST['reminder_date'];
$family_member=$_POST['family_member'];
$bill_status=$_POST['bill_status'];
$bill_note=$_POST['bill_note'];


$InsQuery="UPDATE ".bill_info." SET `bill_no`='$bill_no' ,`bill_date`='$bill_date' ,`bill_category`='$bill_category', 
	 `bill_amount`='$bill_amount',`classification`='$classification' ,`due_date`='$due_date' ,`reminder_date`= '$reminder_date',`family_member`= '$family_member',`bill_status`= '$bill_status',`bill_note`= '$bill_note'
	  where bill_id='$bill_id' "; 
	  
	 	SelQuery="SELECT * FROM `bill_info` WHERE `bill_id` ="$bill_id"";



$q1=mysql_query($SelQuery);
$nt1= mysql_fetch_array($q1);
	



echo mysql_error();

?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Family Finance Alert System</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- end loader -->
      <div id="mySidepanel" class="sidepanel">
          <a href="javascript:void(0)" class="closebtn" onClick="closeNav()">×</a>
         <a href="index.php">Home</a>
         <a href="add_bill.php">Add Bill</a>
         <a href="view_up_bill.php">Upcomming Bill</a>
         <a href="view_over_bill.php">Over due Bill</a>
         <a href="view_paid_bill.php">Paid Bill</a>
         <a href="search_bill.php">Search Bill</a>
         <a href="view_calender.php">Calender View</a>
      </div>
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="header">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                     <div class="sea_icon d_none ">
                        <a href="#"><i class="fa fa-search" aria-hidden="true"></i></a>
                     </div>
                  </div>
                 <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col logo_section">
                     <div class="full">
                        <div class="center-desk">
                            <!--<div class="logo">
                              <a href="index.html"><img src="images/logo.png" alt="#" /></a>
                           </div>-->
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4">
                     <div class="right_bottun">
                        <button class="openbtn" onClick="openNav()"><img src="images/menu_icon.png" alt="#"/> </button> 
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- end header inner -->
      <!-- end header -->
      <!-- banner -->
      <section class="banner_main">
                     
                        <div class="text-bg">
                           <h1>Family Finance</h1>
                           <span>Alert System</span>
                           
                        </div>
                   
        
      </section>
      <!-- end banner -->
      <!-- about section -->
  <!-- about section -->
      <!-- software section -->
       <div class="titlepage">
       <div class="col-md-12">
       <p>    </p>
      <h2 align="center">Add Bill</h2>
                 
<form action="update_save.php" method="post" name="frm_add" id="frm_add" onSubmit="return user_validation();">
<table height="334" border="0" align="center" cellpadding="5" cellspacing="10" >

  <tr>
    <td colspan="2" ><center ><h1> <strong> Form to add new bill.  </strong></h1></center></td>
  </tr>
  <tr>
    <td align="char"><strong>BILL NO:</strong></td>
    <td align="left" ><input name="bill_no" type="text" class="textbox" id="bill_no"  value="<?php echo $nt1['bill_no'];?>"/></td>
  </tr>
  <tr>
    <td align="char"><strong>BILL DATE:</strong></td>
    <td align="left" ><input type = "date" name="bill_date" id="bill_date" value="<?php echo $nt1['bill_date'];?>"> </td>
  </tr>
  <tr>
    <td align="char"><strong>BILL CATEGORY:</strong></td>
    <td align="left" ><select name="bill_category" id="bill_category" class="textbox" >
    <option value="<?php echo $nt1['bill_category'];?>">Category</option>
      <option value="EB">EB</option>
      <option value="GAS">GAS</option>
      <option value="CAR_INSURANCE">Car Insurance</option>
      <option value="LIFE_INSURANCE">Life Insurance</option>
      <option value="HOUSE_RENT">House Rent</option>
      <option value="CAR_LOAN">Car Loan</option>
      <option value="HOUSING_LOAN">Housing Loan</option>
      <option value="JEWEL_LOAN">Jewel Loan</option>
      <option value="CABLE">Cable</option>
        
      </select></td>
  </tr>
  <tr>
    <td align="char"><strong>BILL AMOUNT:</strong></td>
    <td align="left" > <input type = "text"  name="bill_amount" id="bill_amount" value="<?php echo $nt1['bill_amount'];?>">   </td>
  </tr>
  <tr>
    <td align="char"><strong>DUE DATE:</strong></td>
    <td align="left" > <input type = "date"  name="due_date" id="due_date" value="<?php echo $nt1['due_date'];?>">   </td>
  </tr>
  <tr>
    <td align="char"><strong>REMINDER DATE:</strong></td>
    <td align="left" ><input type = "date"  name="reminder_date" id="reminder_date" value="<?php echo $nt1['reminder_date'];?>"> </td>
  </tr>
 <tr>
    <td align="char"><strong>Alert Member:</strong></td>
    <td align="left" ><select name="family_member" id="family_member" class="textbox" value="<?php echo $nt1['family_member'];?>" >
  
      <option value="9042222230">Father</option>
      <option value="9042222231">Mother</option>
      <option value="sushmajeyamary2004@gmail.com">Myself</option>
                  
      </select></td>
  </tr> 
   <tr>
    <td align="char"><strong>Bill status:</strong></td>
    <td align="left" ><select name="bill_status" id="bill_status" class="textbox" value="<?php echo $nt1['bill_status'];?>" >

      <option value="Paid">Paid</option>
      <option value="Not Paid">Not Paid</option>
                  
      </select></td>
  </tr> 


 
  
    <td align="char"><strong>NOTE (If any):</strong></td>
    <td align="left" >
      <textarea name="bill_note" id="bill_note" cols="45" rows="5" value="<?php echo $nt1['bill_note'];?>"></textarea>
    </td>
  </tr>
  
  <tr> 
            <td class="content">&nbsp;</td>
            <td><input name="add_bill" type="submit" class="submitbutton" id="add_bill" value="Update Bill" /></td>
          </tr>
          <tr>
</table>
</form>
</div>
</div>


<?php include ('team.php');?>
      <!-- end Our  team section -->
      <!-- contact section -->
     <!-- <div id="contact" class="contact">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage">
                     <h2>Request  A  Call  Back</h2>
                     <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore </p>
                  </div>
               </div>
            </div>
         </div>
         <div class="con_bg">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-md-6">
                     <form id="request" class="main_form">
                        <div class="row">
                           <div class="col-md-12 ">
                              <input class="contactus" placeholder="Name" type="type" name="Name"> 
                           </div>
                           <div class="col-md-12">
                              <input class="contactus" placeholder="Email" type="type" name="Email"> 
                           </div>
                           <div class="col-md-12">
                              <input class="contactus" placeholder="Phone Number" type="type" name="Phone Number">                          
                           </div>
                           <div class="col-md-12">
                              <input class="contactusmess" placeholder="Message" type="type" Message="Name">
                           </div>
                           <div class="col-md-12">
                              <button class="send_btn">Send</button>
                           </div>
                           <div class="col-md-12">
                              <ul class="location_form">
                                 <li><a href="#"><i class="fa fa-phone" aria-hidden="true"></i></a>
                                    (+71) 1234567890 (+71) 1234567890
                                 </li>
                                 <li><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i></a>demo@gmail.com</li>
                              </ul>
                           </div>
                           <div class="col-md-12">
                              <ul class="social_icon">
                                 <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                 <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                 <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                              </ul>
                           </div>
                        </div>
                     </form>
                  </div>
                  <div class="col-md-6 padding_right2">
                     <div class="map_section">
                        <div id="map">
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>-->
            </div>          
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
      <script>
         function openNav() {
           document.getElementById("mySidepanel").style.width = "250px";
         }
         
         function closeNav() {
           document.getElementById("mySidepanel").style.width = "0";
         }
      </script>
      <script>
         // This example adds a marker to indicate the position of Bondi Beach in Sydney,
         // Australia.
         function initMap() {
           var map = new google.maps.Map(document.getElementById('map'), {
             zoom: 11,
             center: {lat: 40.645037, lng: -73.880224},
             });
         
         var image = 'images/maps-and-flags.png';
         var beachMarker = new google.maps.Marker({
             position: {lat: 40.645037, lng: -73.880224},
             map: map,
             icon: image
           });
         }
      </script>
      <!-- google map js -->
      <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA8eaHt9Dh5H57Zh0xVTqxVdBFCvFMqFjQ&callback=initMap"></script>
      <!-- end google map js --> 
   </body>
</html>

