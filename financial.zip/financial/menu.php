<div id="mySidepanel" class="sidepanel">
          <a href="javascript:void(0)" class="closebtn" onClick="closeNav()">×</a>
         <a href="index.php">Home</a>
         <a href="add_bill.php">Add Bill</a>
         <a href="view_up_bill.php">Upcomming Bill</a>
         <a href="view_over_bill.php">Over due Bill</a>
         <a href="view_paid_bill.php">Paid Bill</a>
         <a href="search_bill.php">Search Bill</a>

      </div>