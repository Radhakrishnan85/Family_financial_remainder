<div id="team" class="team" >
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage">
                     <h2>Our Team</h2>
                     <p>Four team member
                     </p>
                     <p>&nbsp
                     </p>
                  </div>
               </div>
            </div>
            <div class="row">
             <div class="col-md-4">
                  <div class="team_box">
                    <p>
                       <figure>
                         <!--<img src="images/team_img1.jpg" alt="#"/>-->
                       </figure>
                    </p>
                     <div class="social_box">
                       
                        <h3>Radhakrishnan</h3>
                        <p>II CSE</p>
                    </div>
                 </div>
               </div>
               <div class="col-md-4">
                  <div class="team_box">
                    <p>
                       <figure>
                         <!--<img src="images/team_img1.jpg" alt="#"/>-->
                       </figure>
                    </p>
                     <div class="social_box">
                        
                        <h3>Palpandi</h3>
                        <p>II CSE</p>
                    </div>
                 </div>
               </div>
               
               
            </div>
       <p>&nbsp</p>
         <p>&nbsp</p>
            <div class="row">
             <div class="col-md-4">
                  <div class="team_box">
                    <p>
                       <figure>
                         <!--<img src="images/team_img1.jpg" alt="#"/>-->
                       </figure>
                    </p>
                     <div class="social_box">
                        
                        <h3>Sushma Jeyamary</h3>
                        <p>II CSE</p>
                    </div>
                 </div>
               </div>
               <div class="col-md-4">
                  <div class="team_box">
                    <p>
                       <figure>
                         <!--<img src="images/team_img1.jpg" alt="#"/>-->
                       </figure>
                    </p>
                     <div class="social_box">
                        
                        <h3>Vengadeshan</h3>
                        <p>II CSE</p>
                    </div>
                 </div>
               </div>
               
               
            </div>
         </div>
      </div>
      </table>