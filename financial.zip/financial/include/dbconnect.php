<?php 
ob_start();
error_reporting(E_ERROR | E_WARNING | E_PARSE);
session_start();
$localhost_name="localhost";
$user_name="root";
$password="";
$database_name="finance_alert";

//$localhost_name="localhost";
//$user_name="ihrein";
//$password="ih09*re19$";
//$database_name="ihrein_student";

$con = mysql_connect($localhost_name,$user_name,$password);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
mysql_select_db($database_name, $con);


?>
 